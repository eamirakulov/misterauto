$(function() {
	$('#carousel').slick({
		arrows: true
	});
	$('.autos').slick({
		arrows: true,
		slidesToShow: 7
	});
	$('.parts').slick({
		arrows: true,
		slidesToShow: 7
	});
})